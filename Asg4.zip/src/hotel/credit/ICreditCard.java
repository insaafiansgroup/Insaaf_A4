package hotel.credit;

public interface ICreditCard {

	public CreditCardType getType();
	public int getNumber() ;
	public int getCcv();

}
